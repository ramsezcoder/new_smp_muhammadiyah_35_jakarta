<?php
// Production database configuration for Hostinger
// DO NOT commit this file to Git - add to .gitignore
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'u541580780_smpmuh35',
    'user' => 'u541580780_smpmuh35',
    'pass' => 'Muhammadiyah_35!!', // Replace with the password you created
    'charset' => 'utf8mb4'
  ],
  'jwt_secret' => 'm35_hostinger_secret_please_change'
];
?>
